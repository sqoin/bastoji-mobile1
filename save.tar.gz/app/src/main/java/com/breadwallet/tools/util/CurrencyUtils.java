package com.breadwallet.tools.util;

import android.content.Context;
import android.util.Log;

import com.breadwallet.tools.manager.BRReportsManager;
import com.breadwallet.tools.manager.BRSharedPrefs;
import com.breadwallet.wallet.WalletsMaster;
import com.breadwallet.wallet.abstracts.BaseWalletManager;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Currency;
import java.util.Locale;

/**
 * BreadWallet
 * <p/>
 * Created by Mihail Gutan <mihail@breadwallet.com> on 6/28/16.
 * Copyright (c) 2016 breadwallet LLC
 * <p/>
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * <p/>
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * <p/>
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

public class CurrencyUtils {
    public static final String TAG = CurrencyUtils.class.getName();
    private static final String KRONE = "DKK";
    private static final String POUND = "GBP";
    private static final String EURO = "EUR";

    public static String getFormattedAmount(Context app, String iso, BigDecimal amount) {
        //Use default (wallet's maxDecimal places)
        return getFormattedAmount(app, iso, amount, -1, true);
    }

    /**
     * @param app                       - the Context
     * @param currencyCode              - the currency we want to format the amount for
     * @param amount                    - the smallest denomination currency (e.g. dollars or satoshis)
     * @param maxDecimalPlacesForCrypto - max decimal places to use or -1 for wallet's default
     * @param displayCurrencyCode       - if true include the currency code in the output string otherwise not
     * @return - the formatted amount e.g. $535.50 or b5000
     */
    public static String getFormattedAmount(Context app, String currencyCode, BigDecimal amount, int maxDecimalPlacesForCrypto, boolean displayCurrencyCode) {
        if (amount == null) {
            amount = BigDecimal.ZERO;
        }
        if (Utils.isNullOrEmpty(currencyCode)) throw new RuntimeException("need iso for formatting!");
        DecimalFormat currencyFormat;
        // This formats currency values as the user expects to read them (default locale).
        currencyFormat = (DecimalFormat) DecimalFormat.getCurrencyInstance(Locale.getDefault());
        // This specifies the actual currency that the value is in, and provide
        // s the currency symbol.
        DecimalFormatSymbols decimalFormatSymbols = currencyFormat.getDecimalFormatSymbols();
        BaseWalletManager wallet = WalletsMaster.getInstance().getWalletByIso(app, currencyCode);
        currencyFormat.setGroupingUsed(true);
        currencyFormat.setRoundingMode(BRConstants.ROUNDING_MODE);
        if (wallet != null) {
            amount = wallet.getCryptoForSmallestCrypto(app, amount);
            decimalFormatSymbols.setCurrencySymbol("");
            currencyFormat.setDecimalFormatSymbols(decimalFormatSymbols);
            currencyFormat.setMaximumFractionDigits(maxDecimalPlacesForCrypto == -1 ? wallet.getMaxDecimalPlaces(app) : maxDecimalPlacesForCrypto);
            currencyFormat.setMinimumFractionDigits(0);
            return displayCurrencyCode ? String.format("%s %s", currencyFormat.format(amount), currencyCode.toUpperCase()) : currencyFormat.format(amount) ;
        } else {
            try {
                Currency currency = Currency.getInstance(currencyCode);
                String symbol = currency.getSymbol();
                decimalFormatSymbols.setCurrencySymbol(symbol);
                currencyFormat.setDecimalFormatSymbols(decimalFormatSymbols);
                currencyFormat.setNegativePrefix("-" + symbol);
                currencyFormat.setMaximumFractionDigits(currency.getDefaultFractionDigits());
                currencyFormat.setMinimumFractionDigits(currency.getDefaultFractionDigits());
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "Currency not found for " + currencyCode, e);
                BRReportsManager.reportBug(new IllegalArgumentException("Illegal currency code: " + currencyCode));
            }
            return currencyFormat.format(amount);
        }
    }

    public static String getSymbolByIso(Context app, String iso) {
        String symbol;
        BaseWalletManager wallet = WalletsMaster.getInstance().getWalletByIso(app, iso);
        if (wallet != null) {
            symbol = wallet.getSymbol(app);
        } else {
            Currency currency;
            try {
                currency = Currency.getInstance(iso);
            } catch (IllegalArgumentException e) {
                currency = Currency.getInstance(Locale.getDefault());
            }
            symbol = currency.getSymbol();
        }
        return Utils.isNullOrEmpty(symbol) ? iso : symbol;
    }

    public static int getMaxDecimalPlaces(Context app, String iso) {
        BaseWalletManager wallet = WalletsMaster.getInstance().getWalletByIso(app, iso);
        if (wallet == null) {
            Currency currency = Currency.getInstance(iso);
            return currency.getDefaultFractionDigits();
        } else {
            return wallet.getMaxDecimalPlaces(app);
        }

    }

    public static boolean isBuyNotificationNeeded(Context context) {
        String fiatCurrencyCode = BRSharedPrefs.getPreferredFiatIso(context);
        return KRONE.equalsIgnoreCase(fiatCurrencyCode) || POUND.equalsIgnoreCase(fiatCurrencyCode) || EURO.equalsIgnoreCase(fiatCurrencyCode);
    }

}
